/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_210()
{
    return 2429000008U;
}

unsigned getval_380()
{
    return 3284633928U;
}

unsigned addval_188(unsigned x)
{
    return x + 1606651984U;
}

void setval_414(unsigned *p)
{
    *p = 2697171032U;
}

unsigned addval_187(unsigned x)
{
    return x + 2421730955U;
}

unsigned getval_236()
{
    return 3281025242U;
}

void setval_372(unsigned *p)
{
    *p = 2428995912U;
}

void setval_428(unsigned *p)
{
    *p = 3284650312U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

void setval_290(unsigned *p)
{
    *p = 3766569141U;
}

void setval_266(unsigned *p)
{
    *p = 3526939017U;
}

unsigned addval_153(unsigned x)
{
    return x + 3286272328U;
}

void setval_341(unsigned *p)
{
    *p = 3269495112U;
}

unsigned addval_434(unsigned x)
{
    return x + 3229142665U;
}

void setval_318(unsigned *p)
{
    *p = 3353381192U;
}

unsigned addval_489(unsigned x)
{
    return x + 3286273352U;
}

unsigned addval_189(unsigned x)
{
    return x + 3247493513U;
}

unsigned addval_360(unsigned x)
{
    return x + 2429454672U;
}

unsigned addval_241(unsigned x)
{
    return x + 3854811785U;
}

unsigned addval_458(unsigned x)
{
    return x + 1908657833U;
}

unsigned getval_403()
{
    return 3680554633U;
}

unsigned getval_472()
{
    return 3383021961U;
}

unsigned addval_209(unsigned x)
{
    return x + 3230977673U;
}

unsigned getval_195()
{
    return 3682910857U;
}

unsigned getval_369()
{
    return 3677930137U;
}

unsigned getval_330()
{
    return 2445445453U;
}

unsigned getval_463()
{
    return 3525365449U;
}

unsigned addval_371(unsigned x)
{
    return x + 2425409161U;
}

void setval_117(unsigned *p)
{
    *p = 3677929993U;
}

unsigned getval_155()
{
    return 3375940235U;
}

unsigned getval_272()
{
    return 3375944089U;
}

unsigned getval_431()
{
    return 2430634312U;
}

unsigned addval_217(unsigned x)
{
    return x + 3374371209U;
}

unsigned addval_231(unsigned x)
{
    return x + 2428668120U;
}

unsigned getval_482()
{
    return 2446231892U;
}

unsigned addval_336(unsigned x)
{
    return x + 3281113481U;
}

void setval_356(unsigned *p)
{
    *p = 2425409993U;
}

unsigned getval_286()
{
    return 3286272840U;
}

void setval_106(unsigned *p)
{
    *p = 3229926089U;
}

void setval_143(unsigned *p)
{
    *p = 2430634313U;
}

void setval_267(unsigned *p)
{
    *p = 3676885385U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
